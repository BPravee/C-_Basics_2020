﻿namespace AssignmentOne
{
    public interface ILogger
    {
        void Write(string msg);
    }
}