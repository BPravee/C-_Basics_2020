﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentOne
{
    public class DBLogger:ILogger
    {
        public void Write(string msg)
        {
            //DB
            Console.WriteLine("DB Log");
        }
    }
}
