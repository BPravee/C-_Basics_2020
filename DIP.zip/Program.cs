﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentOne
{
    class Program
    {
        static void Main(string[] args)
        {

          ILogger _logger  =new ConsoleLogger();
            PatientDataValidator _validator = new PatientDataValidator(_logger);
            _validator.Validate(null, null, null, null);

            _logger = new DBLogger();
            _validator = new PatientDataValidator(_logger);
            _validator.Validate(null, null, null, null);


        }
    }
}
