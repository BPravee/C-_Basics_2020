﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentOne
{
    //Low Level Module
    //ConsoleLogger Implements ILogger
    public class ConsoleLogger : ILogger
    {
        public void SetMessageSize(int size) { }
        public void SetTextColor(string color) { }
        public void Write(string msg)
        {
            System.Console.WriteLine(msg);
        }
    }
}
